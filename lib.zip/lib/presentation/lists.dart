import 'dart:convert';
import 'package:http/http.dart' as http;

import 'package:facebook_clone/core/constants/post.dart';
import 'package:flutter/material.dart';

/* List localPostJson = [
  [
    "Post Title",
    "alot of talks in this descreption because its just a dummy data",
    10,
    3,
    58,
    ["test", "welocme"]
  ],
  [
    "Post Title 2",
    "more and more alot of talks in this descreption because its just a dummy data",
    22,
    120,
    580,
    ["more test", "welocme"]
  ],
];

List localPosts = List.generate(localPostJson.length, (index) {
  return Post(
      title: localPostJson[index][0],
      body: localPostJson[index][1],
      likes: localPostJson[index][2],
      comments: localPostJson[index][3],
      views: localPostJson[index][4],
      tags: localPostJson[index][5]);
});

List<Widget> localPostWidgets = List.generate(localPosts.length, (index) {
  Post post = localPosts[index];
  return post.getPost;
}); */

Future<Map<String, dynamic>> fetchPosts() async {
  var url = Uri.parse('https://dummyjson.com/posts');
  try {
    var response = await http.get(url);

    if (response.statusCode == 200) {
      // Decode the JSON data into a Map
      Map<String, dynamic> jsonData = jsonDecode(response.body);
      return jsonData;
    } else {
      print('Failed to load posts: ${response.statusCode}');
      return {}; // Return an empty map on failure
    }
  } catch (e) {
    print('Error: $e');
    return {}; // Return an empty map on error
  }
}

FutureBuilder<Map<String, dynamic>> postsBuilder(){
    return FutureBuilder<Map<String, dynamic>>(
    future: fetchPosts(),
    builder: (context, snapshot) {
      if (snapshot.connectionState == ConnectionState.waiting) {
          return const Center(child: CircularProgressIndicator());
        } 
      List<Widget> postWidgets =
          List.generate(snapshot.data!['posts'].length, (index) {
        Post post = Post.fromJson(snapshot.data!['posts'][index]);
        return post.getPost;
      });
      return ListView(children: postWidgets);
    },
  );
}
