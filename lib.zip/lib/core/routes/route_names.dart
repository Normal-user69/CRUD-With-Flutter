class RouteNames{
  static const String home = "/";
  static const String splash = "splash";
  static const String getAllPosts = "/getAll";
  static const String getPost = "/getPost";
  static const String updatePost = "/update";
  static const String deletePost = "/delete";

    static const Map<String , String> appRoutes = {
    "splash":splash,
    "home":home,
    "getAllPosts":getAllPosts,
    "getPost":getPost,
    "updatePost":updatePost,
    "deletePost":deletePost
  };
  
}