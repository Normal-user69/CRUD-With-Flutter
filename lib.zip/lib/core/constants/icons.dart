import 'package:flutter/material.dart';

class AppIcons {
  static const Icon like = Icon(Icons.thumb_up);
  static const Icon comments = Icon(Icons.comment);
  static const Icon views = Icon(Icons.remove_red_eye);
}
