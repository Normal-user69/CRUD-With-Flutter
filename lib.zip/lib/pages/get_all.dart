import 'package:facebook_clone/presentation/lists.dart';
import 'package:flutter/material.dart';

class GetAll extends StatelessWidget{
  const GetAll({super.key});
  
@override
Widget build(BuildContext context) {
  return Scaffold(
    body: postsBuilder(),
  );
}

}